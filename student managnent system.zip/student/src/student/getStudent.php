<?php
include "./src/db/connection.php"; // Database connection

$sql = "SELECT * FROM student ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>
