<?php include "./src/layout/head.php"; ?>
<?php include "./src/layout/nav.php"; ?>

<div class="container-fluid">
<?php
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        echo '<div class="alert alert-success text-center" role="alert">Student added successfully!</div>';
    } elseif ($_GET['status'] == 'error') {
        echo '<div class="alert alert-danger text-center" role="alert">Error: ' . htmlspecialchars($_GET['message']) . '</div>';
    }
}
?>

<div class="card col-md-8 m-auto">
  <div class="card-header">
    New Student
  </div>
  <div class="card-body">
    <form class="row g-3" action="./src/student/addStudent.php" method="post" enctype="multipart/form-data">
    <div class="col-md-6">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name">
    </div>
    <div class="col-md-6">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email">
    </div>
    <div class="col-6">
        <label for="mobile" class="form-label">Mobile</label>
        <input type="text" class="form-control" id="mobile" name="mobile">
    </div>
    <div class="col-6">
        <label for="address" class="form-label">Address</label>
        <input type="text" class="form-control" id="address" name="address" placeholder="Apartment, studio, or floor">
    </div>
    <div class="col-md-6">
        <label for="inputCity" class="form-label">City</label>
        <input type="text" class="form-control" name="city" id="inputCity">
    </div>
    <div class="col-md-4">
        <label for="inputState" class="form-label">State</label>
        <select id="inputState" name="state" class="form-select">
        <option selected>Choose...</option>
        <option>...</option>
        </select>
    </div>
    <div class="col-md-2">
        <label for="inputZip" class="form-label">Zip</label>
        <input type="text" name="zip" class="form-control" id="inputZip">
    </div>
    <div class="col-12">
        <label for="profile_pic" class="form-label">Profile Picture</label>
        <input type="file" class="form-control" name="profile_pic" id="profile_pic" accept="image/*">
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Create New</button>
    </div>
    </form>
  </div>
</div>

</div>
    
</body>
</html>