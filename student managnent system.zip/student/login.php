<?php include "./src/layout/head.php"; ?>
  <body class="d-flex align-items-center py-4 bg-body-tertiary" cz-shortcut-listen="true">
<main class="form-signin w-50 m-auto pt-4">
    <?php
if (isset($_GET['status'])) {
    if (($_GET['status']=="success")) {
        echo "<div class='alert alert-success text-center' role='alert'>Student Added Successfully!</div>";
    }elseif (($_GET['status']=="error")) {
        echo "<div class='alert alert-danger' role='alert'>Error: " .htmlspecialchars($_GET['message'])."</div>";
    }
}
?>
  <form action="./src/auth/login.php" method="post">
    <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

    <div class="form-floating mb-3">
      <input type="email" class="form-control" id="email" placeholder="name@example.com" name="email">
      <label for="email">Email address</label>
    </div>
    <div class="form-floating mb-3">
      <input type="password" class="form-control" id="password" placeholder="Password" name="password">
      <label for="password">Password</label>
    </div>

    <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-body-secondary">©2025</p>
  </form>
</main>
</body>