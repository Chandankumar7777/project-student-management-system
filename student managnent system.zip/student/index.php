<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(!isset($_SESSION['user_id'])){
    header("Location: ./login.php");
    exit;
}
?>
<?php include "./src/layout/head.php"; ?>
<?php include "./src/layout/nav.php"; ?>
<?php include "./src/db/connection.php"; ?>

<div class="container-fluid">
    <div class="row gap-3">
        <div class="col-md-2 bg-primary text-center text-white m-auto">
            <h4>Total Student</h4>
            <h5>10</h5>
        </div>
        <div class="col-md-2 bg-primary text-center text-white m-auto">
            <h4>Total Student</h4>
            <h5>10</h5>
        </div>
        <div class="col-md-2 bg-primary text-center text-white m-auto">
            <h4>Total Student</h4>
            <h5>10</h5>
        </div>
        <div class="col-md-2 bg-primary text-center text-white m-auto">
            <h4>Total Student</h4>
            <h5>10</h5>
        </div>
    </div>
</div>
    
</body>
</html>